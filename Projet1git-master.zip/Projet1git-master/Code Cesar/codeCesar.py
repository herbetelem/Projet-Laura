print("Pour ce jeu tu devras trouver comment s'ecrit ton nom avec la clé que tu auras choisis")
print("Selon la clé que tu choisiras, les lettre seront remplacé")
print("Admettions tu choisis la lettre B, ca clé est choisis aléatoirement")
print("Pour l'exemple on va dire que B vaut trois ")
print("Donc si tu t'appel Pierre, chaque lettre vont etre décalé de 3 dans l'alphabet")

