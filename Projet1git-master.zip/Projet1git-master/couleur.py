import Variable

def colorMap():
    if caractere == "♣":
        caractere = Variable.color_code["♣"]
    